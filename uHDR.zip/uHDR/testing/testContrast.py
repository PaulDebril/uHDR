from guiQt.Contrast import Contrast

def test() -> Contrast:
    
    contrast : Contrast = Contrast()


    return contrast